class ProductRepository():
    def __init__(self, products: list=[]):
        self.products = products

    def add(self, product):
        self.products.append(product)

    def find(self, product_name: str):
        for product in self.products:
            if product_name == product.name:
                return product

    def remove(self, product_name):
        product = ProductRepository.find(self, product_name)
        if product:
            self.products.remove(product)

    def __repr__(self):
        return "\n".join([f"{item.name}: {item.quantity}" for item in self.products])
